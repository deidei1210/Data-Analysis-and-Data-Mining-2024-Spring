# Code

本次作业我们采用两种方式进行血糖水平时间序列的预测。

一种是LSTM一种是Transformer。

在code文件夹中有一个ipynb文件和两个子文件夹。
其中ipynb文件是数据预处理的代码，两个子文件夹分别是LSTM和Transformer方法的实现。
