# Learning StructGPT

我们小组在Github上找到了关于[StructGPT: A General Framework for Large Language Model to Reason on Structured Data](https://arxiv.org/pdf/2305.09645.pdf) (Arxiv 2023).论文的源代码，并进行了实验与分析。

## Usage
### Requirements
需要安装Python库和openai，用于查询OpenAI模型API。

### Prepare Dataset

从[论文中提到的链接处](https://drive.google.com/drive/folders/11_2pqU_MhEtmxpp3zfK_8EJ1bbQzsnfJ?usp=sharing)下载处理过的数据集，然后直接使用它们，并放置在/data目录下。

### Experiment
在```/script```目录下有每个数据集组织的运行和评估脚本。
可以通过命令行的方式逐一运行。
比如我们测试spider数据集下structGPT的表现可以这样运行脚本：

```bash
bash ./scripts/run_spider_wo_icl_v1.sh
```
